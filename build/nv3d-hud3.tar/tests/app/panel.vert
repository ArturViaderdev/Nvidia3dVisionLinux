#version 450
// APP_PANEL=1: a translucent dark green HUD panel (blended: dst * 0.5 + this) over the scene
layout(location = 0) out vec3 col;
void main() {
  const vec2 c[6] = vec2[](vec2(-1, -1), vec2(1, -1), vec2(1, 1), vec2(-1, -1), vec2(1, 1), vec2(-1, 1));
  gl_Position = vec4(vec2(0.2, -0.3) + c[gl_VertexIndex] * vec2(0.45, 0.35), 0.0, 1.0);
  col = vec3(0.0, 0.06, 0.02);
}
